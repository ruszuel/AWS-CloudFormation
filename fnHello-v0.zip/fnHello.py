

def handler(event, context):
    print('hello world')

    return "hello world"