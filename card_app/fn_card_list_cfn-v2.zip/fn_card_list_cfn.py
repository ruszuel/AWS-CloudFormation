import json
import boto3

def handler(event, context):
    dynamodb = boto3.resource('dynamodb')
    table = dynamodb.Table('card_account_cfn')
    response = table.scan()['Items']
    
    return {
        "statusCode": 200,
        "body": json.dumps(response, indent=2)
    }
