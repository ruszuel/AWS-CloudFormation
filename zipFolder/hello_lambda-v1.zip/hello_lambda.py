import json
def handler(event, context):
    print("api invoke")
    print("#event")
    print(json.dumps(event, indent=2))
    return {
        "statusCode": 200,
        "body": "Hello from Lambda"
    }